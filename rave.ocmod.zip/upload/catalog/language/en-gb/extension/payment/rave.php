<?php
// Place Holder Text
$_['text_title'] = "Rave by Flutterwave";
$_['text_testmode'] = "Warning: The payment gateway is in 'Sandbox(test) Mode'. Use a <a href='https://flutterwavedevelopers.readme.io/docs/test-cards' target='_blank'>test card</a>.";
?>


